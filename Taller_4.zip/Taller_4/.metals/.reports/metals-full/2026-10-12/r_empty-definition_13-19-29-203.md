error id: file://<WORKSPACE>/src/main/scala/package.scala:
file://<WORKSPACE>/src/main/scala/package.scala
empty definition using pc, found symbol in pc: 
empty definition using semanticdb
empty definition using fallback
non-local guesses:
	 -coeficiente.
	 -coeficiente#
	 -coeficiente().
	 -scala/Predef.coeficiente.
	 -scala/Predef.coeficiente#
	 -scala/Predef.coeficiente().
offset: 55
uri: file://<WORKSPACE>/src/main/scala/package.scala
text:
```scala
def derivada(f:Double => Double): Double => Double={
  @@coeficiente
}
```


#### Short summary: 

empty definition using pc, found symbol in pc: 