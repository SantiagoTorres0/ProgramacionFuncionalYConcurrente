error id: file://<WORKSPACE>/src/main/scala/pruebas.sc:derivada_Suma.
file://<WORKSPACE>/src/main/scala/pruebas.sc
empty definition using pc, found symbol in pc: 
empty definition using semanticdb
empty definition using fallback
non-local guesses:
	 -Derivacion.derivada_Suma.
	 -Derivacion.derivada_Suma#
	 -Derivacion.derivada_Suma().
	 -derivada_Suma.
	 -derivada_Suma#
	 -derivada_Suma().
	 -scala/Predef.derivada_Suma.
	 -scala/Predef.derivada_Suma#
	 -scala/Predef.derivada_Suma().
offset: 257
uri: file://<WORKSPACE>/src/main/scala/pruebas.sc
text:
```scala
import Derivacion._

// 1. Definición de funciones de prueba
val cte = (x: Double) => 2.0
val f = (x: Double) => (x * x)
val g = (x: Double) => (x * x * x)
// 2. Creación de las funciones derivadas
val prueba_generica = derivada(f)(cte)
val prueba_suma = de@@rivada_Suma(f,g)(cte)

// 3. Evaluación de las derivadas en x = 2
h1(2)
h2(2)
h3(2)
h4(2)

// 4. Evaluación de la constante en x = 5 y x = 6
derivada(cte)(5)
derivada(cte)(6)
```


#### Short summary: 

empty definition using pc, found symbol in pc: 