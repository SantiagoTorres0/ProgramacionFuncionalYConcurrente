error id: file://<WORKSPACE>/src/main/scala/pruebas.sc:
file://<WORKSPACE>/src/main/scala/pruebas.sc
empty definition using pc, found symbol in pc: 
empty definition using semanticdb
empty definition using fallback
non-local guesses:
	 -Derivacion.g.
	 -Derivacion.g#
	 -Derivacion.g().
	 -g.
	 -g#
	 -g().
	 -scala/Predef.g.
	 -scala/Predef.g#
	 -scala/Predef.g().
offset: 358
uri: file://<WORKSPACE>/src/main/scala/pruebas.sc
text:
```scala
import Derivacion._

// 1. Definición de funciones de prueba
val cte = (x: Double) => 2.0
val f = (x: Double) => (x * x)
val g = (x: Double) => (x * x * x)
// 2. Creación de las funciones derivadas
val prueba_generica = derivada(f)(cte)
val prueba_suma = derivada_Suma(f,g)(cte)
val prueba_suma = derivada_Suma(f,g)(cte)
val prueba_resta = derivada_Resta(f,g@@)(cte)
```


#### Short summary: 

empty definition using pc, found symbol in pc: 