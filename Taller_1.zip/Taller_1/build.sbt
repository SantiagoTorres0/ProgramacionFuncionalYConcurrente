scalaVersion := "3.3.3"

name := "Taller_1"
organization := "com.ejemplo"
version := "0.1.0"
